'use strict';

const byId = id => document.getElementById(id);
const finite = x => typeof x === 'number' && Number.isFinite(x);
const pct = x => finite(x) ? (x * 100).toFixed(1) + '%' : '—';
const list = x => Array.isArray(x) ? x : [];
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

const classes = ['normal', 'anomaly', 'worst_anomaly'];

const stateMeta = {
  normal: {
    label: 'ทำงานปกติ',
    sub: 'Normal',
    tag: 'NORMAL',
    advice: 'แรงสั่นสะเทือนอยู่ในเกณฑ์มาตรฐาน เครื่องจักรพร้อมทำงานต่อเนื่อง',
    icon: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>',
  },
  anomaly: {
    label: 'พบความผิดปกติ',
    sub: 'Anomaly',
    tag: 'WARNING',
    advice: 'ตรวจพบแรงสั่นผิดปกติระดับเฝ้าระวัง แนะนำให้ตรวจสอบเครื่องจักร',
    icon: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  },
  worst_anomaly: {
    label: 'ผิดปกติรุนแรง',
    sub: 'Worst anomaly',
    tag: 'CRITICAL',
    advice: 'แรงสั่นสะเทือนสูงผิดปกติรุนแรง ควรหยุดเครื่องและเข้าตรวจสอบทันที',
    icon: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
  },
  unknown: {
    label: 'รอผลจำแนก',
    sub: 'Analyzing',
    tag: 'SAMPLING',
    advice: 'กำลังรวบรวมหน้าต่างสัญญาณเพื่อประมวลผลด้วยโมเดล',
    icon: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
  },
  offline: {
    label: 'ออฟไลน์',
    sub: 'Offline',
    tag: 'OFFLINE',
    advice: 'ยังไม่ได้รับสัญญาณจากบอร์ดเซนเซอร์',
    icon: '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
  },
};

const pages = {
  overview: ['ภาพรวมเครื่องจักร', 'Monitor'],
  alerts: ['ศูนย์แจ้งเตือน', 'Alerts'],
  history: ['ประวัติการวัด', 'History'],
  settings: ['ตั้งค่าหน้าจอ', 'Settings'],
};

const healthText = {
  'Waiting for samples': 'กำลังรอตัวอย่างจากแหล่งข้อมูล',
  'Collecting samples': 'กำลังสะสมตัวอย่างให้ครบหน้าต่าง',
  'Receiving samples': 'รับข้อมูลและประมวลผลแล้ว',
  'Constant sensor window': 'สัญญาณค้างทั้งสามแกน',
  'No recent sample': 'สัญญาณขาดหาย',
  'Recorded file finished': 'เล่นไฟล์บันทึกจบแล้ว',
  'Sample gap; collecting a new window': 'ตัวอย่างขาดหาย กำลังเริ่มหน้าต่างใหม่',
  'Stream resumed; collecting a new window': 'สัญญาณกลับมาแล้ว กำลังเริ่มหน้าต่างใหม่',
  'Invalid sample; collecting a new window': 'ตัวอย่างไม่ถูกต้อง กำลังเริ่มหน้าต่างใหม่',
};

const clockFmt = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Asia/Bangkok',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false,
});
const timeStr = x => finite(x) ? clockFmt.format(new Date(x * 1000)) : '—';
const dayStr = x => finite(x) ? new Date(x * 1000).toLocaleDateString('th-TH', { timeZone: 'Asia/Bangkok' }) : '';
const markTime = x => finite(x) ? `${dayStr(x)} ${timeStr(x)}` : '—';

const elem = (tag, content, cls) => {
  const node = document.createElement(tag);
  if (content !== null && content !== undefined) node.textContent = content;
  if (cls) node.className = cls;
  return node;
};

function withAlpha(color, alpha) {
  const c = String(color || '').trim();
  if (/^#[0-9a-f]{6}$/i.test(c)) {
    const r = parseInt(c.slice(1, 3), 16);
    const g = parseInt(c.slice(3, 5), 16);
    const b = parseInt(c.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  const m = c.match(/^rgba?\((\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
  if (m) return `rgba(${m[1]}, ${m[2]}, ${m[3]}, ${alpha})`;
  return c || `rgba(190, 242, 100, ${alpha})`;
}

/* ==========================================================================
   Preferences (localStorage)
   ========================================================================== */
const readPref = (key, fallback) => {
  try { return localStorage.getItem('armageddon-' + key) ?? fallback; } catch { return fallback; }
};

const pref = {
  theme: readPref('theme', 'dark'),
  units: readPref('units', 'g'),
  range: Number(readPref('range', '300')),
  notices: readPref('notices', 'true') === 'true',
};
if (![60, 300, 900].includes(pref.range)) pref.range = 300;
if (!['dark', 'light'].includes(pref.theme)) pref.theme = 'dark';
if (pref.units !== 'mg') pref.units = 'g';

const unitScale = () => (pref.units === 'mg' ? 1000 : 1);

const state = {
  data: {},
  api: false,
  paused: null,
  view: 'overview',
  performance: null,
  lastAlert: null,
  alertKey: '',
  alertFilter: 'all',
  historyFilter: 'all',
  visibleAxes: { x: true, y: true, z: true },
  lastVisualState: null,
  hoverIndex: {},
};

/* ==========================================================================
   Toast Notifications
   ========================================================================== */
function notify(message, tone = 'amber') {
  const stack = byId('toastStack');
  if (!stack) return;
  const toast = elem('div', null, `toast tone-${tone}`);
  const dot = elem('span', null, 'pulse-dot');
  dot.style.background = `var(--${tone})`;
  dot.style.width = '8px';
  dot.style.height = '8px';
  dot.style.borderRadius = '50%';
  dot.style.flexShrink = '0';
  toast.append(dot, elem('span', message));
  stack.append(toast);

  const dismiss = () => {
    if (toast.classList.contains('leaving')) return;
    toast.classList.add('leaving');
    setTimeout(() => toast.remove(), 300);
  };
  toast.addEventListener('click', dismiss);
  setTimeout(dismiss, 5500);
}

/* ==========================================================================
   Preferences Sync & Routing
   ========================================================================== */
function setPref(key, value) {
  pref[key] = value;
  try { localStorage.setItem('armageddon-' + key, String(value)); } catch {}
  syncPrefs();
  render();
}

function syncPrefs() {
  document.documentElement.dataset.theme = pref.theme;
  byId('theme').value = pref.theme;
  byId('units').value = pref.units;
  byId('notices').checked = pref.notices;
  byId('range').value = byId('historyRange').value = String(pref.range);

  document.querySelectorAll('.theme-card').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.themeChoice === pref.theme);
  });
  document.querySelectorAll('[data-unit]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.unit === pref.units);
  });
  document.querySelectorAll('[data-range]').forEach(btn => {
    btn.classList.toggle('active', Number(btn.dataset.range) === pref.range);
  });
}

function route() {
  const hash = location.hash.slice(1);
  state.view = Object.hasOwn(pages, hash) ? hash : 'overview';

  Object.keys(pages).forEach(k => {
    const sec = byId(k);
    const active = k === state.view;
    sec.hidden = !active;
    if (active) {
      sec.classList.remove('active');
      void sec.offsetWidth;
      sec.classList.add('active');
    }
  });

  document.querySelectorAll('.nav-item').forEach(a => {
    const active = a.dataset.page === state.view;
    a.classList.toggle('current', active);
    if (active) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });

  [byId('pageTitle').textContent, byId('pageContext').textContent] = pages[state.view];
  byId('overviewQuickActions').hidden = state.view !== 'overview';
  if (state.view === 'history') loadPerformance();
  render();
}

function setMetric(id, value, unit) {
  const node = byId(id);
  node.textContent = value ?? '—';
  if (unit && value != null) node.append(elem('small', unit));
}

function details(container, rows) {
  container.replaceChildren(...rows.map(([k, v]) => {
    const r = elem('div');
    r.append(elem('dt', k), elem('dd', v));
    return r;
  }));
}

function currentClass() {
  const d = state.data;
  if (!state.api || !d.connected) return 'offline';
  return Object.hasOwn(stateMeta, d.state) ? d.state : 'unknown';
}

function syncPauseButton() {
  const paused = Boolean(state.paused);
  const btn = byId('pause');
  btn.setAttribute('aria-pressed', String(paused));
  byId('pauseLabel').textContent = paused ? 'ดูต่อ' : 'หยุดกราฟ';
  byId('pauseIco').innerHTML = paused
    ? '<polygon points="6 4 20 12 6 20 6 4"/>'
    : '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>';
}

/* ==========================================================================
   Main Render Pipeline (100% Real API Data)
   ========================================================================== */
function render() {
  const d = state.data;
  const cls = currentClass();
  const meta = stateMeta[cls] || stateMeta.offline;
  const predicted = classes.includes(cls);
  const streaming = state.api && d.connected;

  document.body.dataset.machineState = cls;
  byId('brandMark').classList.toggle('streaming', streaming && !state.paused);

  const source = {
    board: d.connected ? 'สัญญาณสด' : 'บอร์ดออฟไลน์',
    offline: 'ออฟไลน์',
    replay: 'เล่นไฟล์บันทึก',
  }[d.source] || 'ออฟไลน์';

  byId('source').textContent = state.api ? source : 'API ออฟไลน์';
  byId('sourcePill').dataset.source =
    state.api && (d.connected || d.source === 'replay') ? d.source : 'offline';

  const liveChip = byId('liveChip');
  if (state.paused) {
    liveChip.dataset.state = 'paused';
    byId('liveChipText').textContent = 'PAUSED';
  } else if (streaming) {
    liveChip.dataset.state = 'live';
    byId('liveChipText').textContent = d.source === 'replay' ? 'REPLAY 62.5 Hz' : 'LIVE 62.5 Hz';
  } else {
    liveChip.dataset.state = 'offline';
    byId('liveChipText').textContent = 'STANDBY';
  }

  const openAlerts = list(d.alerts).filter(a => !a.acknowledged).length;
  const badge = byId('alertCount');
  if (badge.textContent !== String(openAlerts) && openAlerts > 0) {
    badge.style.animation = 'none';
    void badge.offsetWidth;
    badge.style.animation = '';
  }
  badge.textContent = String(openAlerts);
  badge.hidden = !openAlerts;

  const led = byId('deviceLed');
  led.classList.toggle('on', d.source === 'board' && state.api && d.connected);
  byId('deviceMeta').textContent = !state.api
    ? 'ขาดการเชื่อมต่อ Local API'
    : d.connected
      ? `เชื่อมต่อปกติ · ${d.window_samples ?? '—'} samples`
      : d.mcu_heartbeat
        ? `MCU Heartbeat (อ่าน ${d.mcu_successful_reads ?? 0})`
        : 'รอสัญญาณจากเซนเซอร์';

  if (state.view === 'overview') {
    const card = byId('statusCard');
    card.dataset.state = cls;
    if (state.lastVisualState !== cls) {
      byId('statusIcon').innerHTML = meta.icon;
      state.lastVisualState = cls;
    }
    byId('statusSubTag').textContent = meta.tag;
    byId('classification').textContent = meta.label;
    byId('statusAdvice').textContent = meta.advice;
    byId('health').textContent = state.api
      ? (healthText[d.health] || d.health || 'รอสถานะระบบ')
      : 'เชื่อมต่อโปรแกรมรับข้อมูลไม่ได้';

    // Confidence + SVG Ring
    const conf = predicted && finite(d.confidence) ? d.confidence : null;
    setMetric('confidence', conf !== null ? (conf * 100).toFixed(1) : null, '%');
    const circumference = 119.38;
    const ring = byId('confRing');
    ring.style.strokeDashoffset = conf !== null ? String(circumference * (1 - clamp(conf, 0, 1))) : String(circumference);
    ring.style.stroke = cls === 'worst_anomaly' ? 'var(--red)' : cls === 'anomaly' ? 'var(--amber)' : cls === 'normal' ? 'var(--green)' : 'var(--accent)';

    // RPM + Rotor
    const hasRpm = streaming && finite(d.rpm);
    setMetric('rpm', hasRpm ? Math.round(d.rpm).toLocaleString('en-US') : null, 'RPM');
    byId('rpmSource').textContent = hasRpm
      ? (d.source === 'replay' ? 'ค่าที่บันทึกไว้ในไฟล์' : 'ค่ารอบจากแหล่งวัด')
      : 'รอข้อมูล RPM';
    const rotor = byId('rotorBox');
    rotor.classList.toggle('spinning', hasRpm && d.rpm > 0 && !state.paused);
    if (hasRpm && d.rpm > 0) {
      rotor.style.setProperty('--spin-dur', clamp(2400 / d.rpm, 0.55, 3.5).toFixed(2) + 's');
    }

    // Latency + Live RMS
    const hasLat = predicted && finite(d.latency_ms);
    setMetric('latency', hasLat ? Number(d.latency_ms).toFixed(1) : null, 'ms');
    const latPct = hasLat ? clamp((d.latency_ms / 50) * 100, 8, 100) : 0;
    const latBar = byId('latencyBar');
    latBar.style.width = latPct + '%';
    latBar.style.background = !hasLat
      ? 'var(--gray)'
      : d.latency_ms < 20
        ? 'linear-gradient(90deg, var(--green), var(--accent))'
        : d.latency_ms < 40
          ? 'var(--amber)'
          : 'var(--red)';
    byId('latencyHint').textContent = !hasLat
      ? 'ต่อหน้าต่างสัญญาณ'
      : d.latency_ms < 20
        ? 'ประมวลผลเร็ว (Real-time)'
        : 'ต่อหน้าต่างสัญญาณ';

    const lastHist = list(d.history).at(-1);
    const liveRms = streaming && finite(lastHist?.rms) ? lastHist.rms * unitScale() : null;
    byId('liveRmsVal').textContent = liveRms !== null
      ? `${liveRms.toFixed(pref.units === 'g' ? 3 : 1)} ${pref.units}`
      : '—';

    // Classification Bars
    for (const c of classes) {
      const prob = predicted ? d.probabilities?.[c] : null;
      const pctVal = finite(prob) ? clamp(prob * 100, 0, 100) : 0;
      byId('score-' + c).textContent = pct(prob);
      byId('fill-' + c).style.width = pctVal + '%';
      const row = byId('row-' + c);
      if (row) row.classList.toggle('leading', predicted && cls === c);
    }

    byId('updated').textContent = markTime(d.updated_at);
    byId('version').textContent = d.model_version || '—';
    byId('sensor').textContent = !state.api
      ? 'ขาดการเชื่อมต่อ'
      : d.source === 'replay'
        ? 'อ่านไฟล์บันทึก'
        : d.connected
          ? 'เชื่อมต่อ'
          : 'ขาดการเชื่อมต่อ';

  } else if (state.view === 'alerts') {
    renderAlerts();
  } else if (state.view === 'history') {
    renderHistory();
  } else if (state.view === 'settings') {
    details(byId('systemDetails'), [
      ['แหล่งข้อมูล', source],
      ['อุปกรณ์ / ไฟล์', d.source_detail || '—'],
      ['โมเดล', d.model_version || '—'],
      ['ขนาดหน้าต่าง', finite(d.window_samples) ? `${d.window_samples} ตัวอย่าง` : '—'],
      ['MCU Heartbeat', d.mcu_heartbeat ? `ปกติ (อ่านสำเร็จ ${d.mcu_successful_reads ?? 0} ครั้ง)` : 'ไม่พบสัญญาณ'],
      ['อัปเดตล่าสุด', markTime(d.updated_at)],
      ['การเชื่อมต่อ API', state.api ? 'เชื่อมต่อ' : 'ออฟไลน์'],
      ['บริการ', location.origin],
    ]);
  }

  drawCharts();
}

/* ==========================================================================
   Alerts View
   ========================================================================== */
function renderAlerts() {
  const all = list(state.data.alerts).slice().sort((a, b) => b.t - a.t);
  const openList = all.filter(a => !a.acknowledged);
  const criticalCount = all.filter(a => a.state === 'worst_anomaly').length;

  byId('alertTotal').textContent = String(all.length);
  byId('alertOpen').textContent = String(openList.length);
  byId('alertCritical').textContent = String(criticalCount);

  const ackAllBtn = byId('ackAllBtn');
  ackAllBtn.hidden = openList.length === 0;
  ackAllBtn.disabled = !state.api;

  const filtered = all.filter(a => {
    if (state.alertFilter === 'open') return !a.acknowledged;
    if (state.alertFilter === 'acked') return Boolean(a.acknowledged);
    return true;
  });

  const key = JSON.stringify([state.api, state.alertFilter, filtered]);
  if (key === state.alertKey) return;
  state.alertKey = key;

  const container = byId('alertList');
  if (!filtered.length) {
    const empty = elem('div', null, 'empty');
    empty.innerHTML = '<svg class="empty-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>';
    empty.append(elem('span', state.alertFilter === 'open' ? 'ไม่มีเหตุการณ์ที่ค้างรอรับทราบ' : 'ยังไม่มีเหตุการณ์ในรายการนี้'));
    container.replaceChildren(empty);
    return;
  }

  container.replaceChildren(...filtered.map(a => {
    const meta = stateMeta[a.state] || stateMeta.anomaly;
    const row = elem('div', null, `event ${a.state}${a.acknowledged ? ' acked' : ''}`);

    const stamp = elem('div');
    stamp.append(elem('time', timeStr(a.t)), elem('small', dayStr(a.t)));

    const badgeWrap = elem('div');
    badgeWrap.append(
      elem('span', meta.label, `pill ${a.state}`),
      elem('small', a.state === 'worst_anomaly' ? 'ระดับรุนแรง' : 'ระดับเฝ้าระวัง')
    );

    const conf = elem('div');
    conf.append(elem('strong', pct(a.confidence), 'mono'), elem('small', 'คะแนนโมเดล'));

    let action;
    if (a.acknowledged) {
      action = elem('span', null, 'ack-done');
      action.innerHTML = '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="20 6 9 17 4 12"/></svg>รับทราบแล้ว';
    } else {
      action = elem('button', 'รับทราบ', 'action');
      action.disabled = !state.api;
      action.addEventListener('click', async () => {
        await ackSingleAlert(a.id, action);
      });
    }

    row.append(stamp, badgeWrap, conf, action);
    return row;
  }));
}

async function ackSingleAlert(id, btn) {
  if (btn) btn.disabled = true;
  try {
    const res = await fetch('/api/alerts/' + encodeURIComponent(id) + '/ack', {
      method: 'POST',
      signal: AbortSignal.timeout(3500),
    });
    if (!res.ok) throw Error();
    state.alertKey = '';
    notify('บันทึกการรับทราบเหตุการณ์แล้ว', 'green');
    await refresh();
  } catch {
    notify('รับทราบเหตุการณ์ไม่สำเร็จ กรุณาลองอีกครั้ง', 'red');
  } finally {
    if (btn) btn.disabled = !state.api;
  }
}

async function ackAllAlerts() {
  const open = list(state.data.alerts).filter(a => !a.acknowledged);
  if (!open.length) return;
  const btn = byId('ackAllBtn');
  btn.disabled = true;
  try {
    await Promise.all(open.map(a =>
      fetch('/api/alerts/' + encodeURIComponent(a.id) + '/ack', {
        method: 'POST',
        signal: AbortSignal.timeout(3500),
      })
    ));
    state.alertKey = '';
    notify(`รับทราบทั้งหมด ${open.length} เหตุการณ์แล้ว`, 'green');
    await refresh();
  } catch {
    notify('ไม่สามารถรับทราบบางรายการได้ กรุณาลองใหม่', 'red');
  } finally {
    btn.disabled = !state.api;
  }
}

/* ==========================================================================
   History View
   ========================================================================== */
function renderHistory() {
  const d = state.data;
  const summary = d.history_summary || {};
  let totalCounts = 0;

  byId('counts').replaceChildren(...classes.map(k => {
    const meta = stateMeta[k];
    const item = elem('div', null, `stat-box ${k}`);
    const count = summary.counts ? (summary.counts[k] ?? 0) : null;
    const duration = summary.duration_s ? (summary.duration_s[k] ?? 0) : null;
    if (finite(count)) totalCounts += count;
    item.append(
      elem('span', `${meta.label} (${meta.sub})`, 'stat-label'),
      elem('strong', finite(count) ? `${count.toLocaleString('en-US')} ครั้ง` : '—'),
      elem('small', finite(duration) ? `${duration.toFixed(1)} s` : '—')
    );
    return item;
  }));

  const ratioWrap = byId('ratioWrap');
  if (totalCounts > 0) {
    ratioWrap.hidden = false;
    const nPct = ((summary.counts?.normal ?? 0) / totalCounts) * 100;
    const aPct = ((summary.counts?.anomaly ?? 0) / totalCounts) * 100;
    const wPct = ((summary.counts?.worst_anomaly ?? 0) / totalCounts) * 100;
    byId('ratioNormal').style.width = nPct + '%';
    byId('ratioAnomaly').style.width = aPct + '%';
    byId('ratioWorst').style.width = wPct + '%';
    byId('ratioLegend').textContent =
      `สัดส่วนรวม: ปกติ ${nPct.toFixed(1)}% · ผิดปกติ ${aPct.toFixed(1)}% · รุนแรง ${wPct.toFixed(1)}%`;
  } else {
    ratioWrap.hidden = true;
  }

  const rows = list(d.history)
    .filter(h => state.historyFilter === 'all' || h.state === state.historyFilter)
    .slice()
    .sort((a, b) => b.t - a.t);

  byId('historyUnit').textContent = `RMS (${pref.units})`;
  const tbody = byId('historyRows');

  if (rows.length) {
    tbody.replaceChildren(...rows.map(h => {
      const tr = elem('tr');
      const meta = stateMeta[h.state] || stateMeta.unknown;

      tr.append(elem('td', markTime(h.t), 'mono'));

      const stateTd = elem('td');
      stateTd.append(elem('span', meta.label, `pill ${h.state || 'unknown'}`));
      tr.append(stateTd);

      const confTd = elem('td');
      const confWrap = elem('div', null, 'conf-cell');
      const mini = elem('span', null, 'conf-mini');
      const bar = elem('i');
      bar.style.width = finite(h.confidence) ? `${clamp(h.confidence * 100, 0, 100)}%` : '0%';
      mini.append(bar);
      confWrap.append(mini, elem('span', pct(h.confidence), 'mono'));
      confTd.append(confWrap);
      tr.append(confTd);

      const rmsText = finite(h.rms) ? (h.rms * unitScale()).toFixed(pref.units === 'g' ? 4 : 1) : '—';
      tr.append(elem('td', rmsText, 'mono'));
      tr.append(elem('td', finite(h.rpm) ? String(h.rpm) : '—', 'mono'));
      return tr;
    }));
  } else {
    const tr = elem('tr');
    const td = elem('td', 'ยังไม่มีประวัติผลจำแนก', 'empty');
    td.colSpan = 5;
    tr.append(td);
    tbody.replaceChildren(tr);
  }

  renderPerformance();
}

function renderPerformance() {
  const container = byId('performance');
  const p = state.performance;
  if (!p) {
    container.textContent = 'ยังไม่มีผลประเมินในบริการนี้';
    return;
  }
  const measured = p.available ? p : p.development;
  if (!measured) {
    container.textContent = 'รอผลทดสอบจากรอบเดินเครื่องอิสระ';
    return;
  }

  const accVal = finite(measured.accuracy) ? measured.accuracy : null;
  const f1Val = finite(measured.macro_f1) ? measured.macro_f1 : null;

  const note = elem('p', p.available ? 'ผลชุดทดสอบอิสระ' : 'ผลระหว่างพัฒนา · รอทดสอบรอบเดินเครื่องอิสระ', 'metric-foot');
  note.style.marginTop = '0';

  const meters = elem('div', null, 'perf-meters');
  const makeTile = (title, display, ratio) => {
    const tile = elem('div', null, 'perf-tile');
    const bar = elem('div', null, 'perf-bar');
    const fill = elem('i');
    fill.style.width = ratio !== null ? `${clamp(ratio * 100, 0, 100)}%` : '0%';
    bar.append(fill);
    tile.append(elem('span', title, 'cap'), elem('strong', display, 'mono'), bar);
    return tile;
  };
  meters.append(
    makeTile('Accuracy', pct(accVal), accVal),
    makeTile('Macro F1', f1Val !== null ? f1Val.toFixed(3) : '—', f1Val)
  );

  const dl = elem('dl', null, 'system-lines');
  dl.style.marginTop = '8px';
  details(dl, [
    ['วิธีประเมิน', measured.method || measured.evidence || 'ดูรายงานโมเดล'],
    ['ไฟล์ที่ประเมิน', measured.n_files ?? '—'],
    ['กลุ่มประเมิน', measured.n_groups ?? '—'],
  ]);

  container.replaceChildren(note, meters, dl);
}

async function loadPerformance() {
  if (state.performance?.available) return;
  try {
    const res = await fetch('/api/performance', { cache: 'no-store', signal: AbortSignal.timeout(3500) });
    if (res.ok) state.performance = await res.json();
  } catch {}
  if (state.view === 'history') renderPerformance();
}

/* ==========================================================================
   Classification Bars Setup
   ========================================================================== */
function setupBars() {
  const container = byId('bars');
  container.replaceChildren();
  for (const c of classes) {
    const meta = stateMeta[c];
    const row = elem('div', null, `classrow ${c}`);
    row.id = 'row-' + c;
    const head = elem('header');
    const nameWrap = elem('div', null, 'class-name');
    nameWrap.append(elem('span', null, 'class-dot'), elem('span', meta.label), elem('small', meta.sub));
    const pc = elem('span', '—', 'pct');
    pc.id = 'score-' + c;
    const track = elem('div', null, 'track');
    const fill = elem('div', null, 'fill');
    fill.id = 'fill-' + c;
    head.append(nameWrap, pc);
    track.append(fill);
    row.append(head, track);
    container.append(row);
  }
}

/* ==========================================================================
   Enhanced Canvas 2D Charting Engine (Gradients, Crosshair, Floating Tooltip)
   ========================================================================== */
const chartMeta = {};

function formatAxis(x) {
  if (!finite(x)) return '0';
  if (Math.abs(x) >= 1000) return Number(x.toPrecision(3)).toLocaleString('en-US');
  if (Math.abs(x) < 0.01 && x !== 0) return x.toExponential(1);
  return Number(x.toPrecision(3)).toString();
}

function drawGraph(id, lines, opts) {
  const { unit, xUnit, readId, tipId, empty, area = false, zeroMin = false } = opts;
  const canvas = byId(id);
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  if (!w || !h) return;

  const dpi = Math.min(window.devicePixelRatio || 1, 2);
  if (canvas.width !== Math.round(w * dpi) || canvas.height !== Math.round(h * dpi)) {
    canvas.width = Math.round(w * dpi);
    canvas.height = Math.round(h * dpi);
  }

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpi, 0, 0, dpi, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const style = getComputedStyle(document.documentElement);
  const css = k => style.getPropertyValue(k).trim();
  const isDark = document.documentElement.dataset.theme !== 'light';

  const box = { l: 50, r: w - 14, t: 14, b: h - 24 };
  const plotW = box.r - box.l;
  const plotH = box.b - box.t;

  ctx.save();
  ctx.lineWidth = 1;
  ctx.strokeStyle = css('--grid');
  ctx.setLineDash([3, 4]);
  for (let i = 0; i <= 4; i++) {
    const x = box.l + (plotW * i) / 4;
    const y = box.t + (plotH * i) / 4;
    ctx.beginPath();
    ctx.moveTo(x, box.t);
    ctx.lineTo(x, box.b);
    ctx.moveTo(box.l, y);
    ctx.lineTo(box.r, y);
    ctx.stroke();
  }
  ctx.restore();

  const valid = lines
    .map(s => ({ ...s, points: s.points.filter(p => finite(p[0]) && finite(p[1])) }))
    .filter(s => s.points.length);

  if (!valid.length) {
    ctx.fillStyle = css('--muted');
    ctx.font = '500 12.5px "Segoe UI", Tahoma, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(empty, w / 2, h / 2 + 4);
    byId(readId).textContent = '';
    if (tipId) byId(tipId).hidden = true;
    chartMeta[id] = null;
    return;
  }

  let xmin = Infinity, xmax = -Infinity, ymin = Infinity, ymax = -Infinity;
  for (const series of valid) {
    for (const [x, y] of series.points) {
      if (x < xmin) xmin = x;
      if (x > xmax) xmax = x;
      if (y < ymin) ymin = y;
      if (y > ymax) ymax = y;
    }
  }
  if (xmin === xmax) xmin -= 1;
  const pad = (ymax - ymin) * 0.1 || Math.max(Math.abs(ymax) * 0.06, unit === 'RPM' ? 20 : 0.001);
  ymin -= pad;
  ymax += pad;
  if (zeroMin) ymin = Math.max(0, ymin);

  const xPixel = x => box.l + ((x - xmin) / (xmax - xmin)) * plotW;
  const yPixel = y => box.b - ((y - ymin) / (ymax - ymin)) * plotH;

  ctx.font = '10px Consolas, "Courier New", monospace';
  ctx.fillStyle = css('--muted');
  for (let i = 0; i <= 4; i++) {
    const yVal = ymin + ((ymax - ymin) * i) / 4;
    const xVal = xmin + ((xmax - xmin) * i) / 4;
    ctx.textAlign = 'right';
    ctx.fillText(formatAxis(yVal), box.l - 6, yPixel(yVal) + 3);
    ctx.textAlign = 'center';
    ctx.fillText(formatAxis(xVal), xPixel(xVal), h - 7);
  }

  ctx.save();
  ctx.beginPath();
  ctx.rect(box.l, box.t - 2, plotW, plotH + 4);
  ctx.clip();

  for (const series of valid) {
    const col = css(series.color);
    const pts = series.points;

    if (area && pts.length > 1) {
      const grad = ctx.createLinearGradient(0, box.t, 0, box.b);
      grad.addColorStop(0, withAlpha(col, isDark ? 0.28 : 0.18));
      grad.addColorStop(1, withAlpha(col, 0));
      ctx.beginPath();
      ctx.moveTo(xPixel(pts[0][0]), box.b);
      for (const [x, y] of pts) ctx.lineTo(xPixel(x), yPixel(y));
      ctx.lineTo(xPixel(pts[pts.length - 1][0]), box.b);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();
    }

    ctx.save();
    ctx.strokeStyle = col;
    ctx.lineWidth = area ? 2 : 1.75;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    if (isDark) {
      ctx.shadowColor = col;
      ctx.shadowBlur = 5;
    }
    ctx.beginPath();
    pts.forEach(([x, y], idx) => {
      const px = xPixel(x), py = yPixel(y);
      if (idx) ctx.lineTo(px, py);
      else ctx.moveTo(px, py);
    });
    ctx.stroke();
    ctx.restore();

    if (pts.length === 1) {
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.arc(xPixel(pts[0][0]), yPixel(pts[0][1]), 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();

  const hoverX = state.hoverIndex[id];
  if (finite(hoverX) && hoverX >= box.l && hoverX <= box.r) {
    const dataX = xmin + ((hoverX - box.l) / plotW) * (xmax - xmin);
    const nearest = valid.map(s =>
      s.points.reduce((best, p) => (Math.abs(p[0] - dataX) < Math.abs(best[0] - dataX) ? p : best))
    );
    const snapPx = xPixel(nearest[0][0]);

    ctx.save();
    ctx.strokeStyle = css('--line-strong');
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 3]);
    ctx.beginPath();
    ctx.moveTo(snapPx, box.t);
    ctx.lineTo(snapPx, box.b);
    ctx.stroke();
    ctx.restore();

    nearest.forEach(([pxVal, pyVal], i) => {
      const col = css(valid[i].color);
      const px = xPixel(pxVal);
      const py = yPixel(pyVal);
      ctx.save();
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.arc(px, py, 4.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = css('--surface-solid');
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    });

    byId(readId).textContent =
      `${formatAxis(nearest[0][0])} ${xUnit} · ` +
      valid.map((s, i) => `${s.label} ${formatAxis(nearest[i][1])} ${unit}`).join(' · ');

    if (tipId) {
      const tip = byId(tipId);
      tip.hidden = false;
      tip.innerHTML =
        `<div class="tt-head">${formatAxis(nearest[0][0])} ${xUnit}</div>` +
        valid.map((s, i) =>
          `<div class="tt-row"><span class="tt-dot" style="background:${css(s.color)}"></span>${s.label}: <b>${formatAxis(nearest[i][1])}</b> ${unit}</div>`
        ).join('');
      const tipW = tip.offsetWidth || 130;
      const left = snapPx + 14 + tipW > w ? Math.max(8, snapPx - tipW - 14) : snapPx + 14;
      tip.style.transform = `translate3d(${Math.round(left)}px, 6px, 0)`;
    }
  } else {
    byId(readId).textContent = '';
    if (tipId) byId(tipId).hidden = true;
  }

  chartMeta[id] = { lines, opts };
  if (!canvas.dataset.bound) {
    canvas.dataset.bound = '1';
    canvas.addEventListener('pointermove', e => {
      state.hoverIndex[id] = e.offsetX;
      if (chartMeta[id]) drawGraph(id, chartMeta[id].lines, chartMeta[id].opts);
    });
    canvas.addEventListener('pointerleave', () => {
      state.hoverIndex[id] = null;
      if (chartMeta[id]) drawGraph(id, chartMeta[id].lines, chartMeta[id].opts);
    });
  }
}

function drawCharts() {
  if (!['overview', 'history'].includes(state.view)) return;
  const d = state.paused || state.data;
  const history = list(d.history);
  const end = history.reduce((n, item) => Math.max(n, item.t || 0), 0);
  const recent = history.filter(x => x.t >= end - pref.range).sort((a, b) => a.t - b.t);
  const factor = unitScale();

  if (state.view === 'history') {
    drawGraph(
      'rpmTrend',
      [{ label: 'RPM', color: '--y', points: recent.map(h => [h.t - end, h.rpm]) }],
      { unit: 'RPM', xUnit: 's', readId: 'rpmRead', tipId: 'rpmTip', empty: 'ยังไม่มีรอบเครื่องในช่วงที่เลือก', area: true, zeroMin: true }
    );
    return;
  }

  const samples = list(d.waveform);
  const last = samples.at(-1)?.t;
  const usable = Boolean(state.paused) || (state.api && d.connected);

  byId('waveTime').textContent = state.paused ? `หยุดที่ ${timeStr(d.updated_at)}` : '';
  byId('waveUnit').textContent = `ความเร่ง (${pref.units})`;
  byId('rmsUnit').textContent = `RMS (${pref.units})`;
  byId('specUnit').textContent = `แอมพลิจูด (${pref.units})`;

  const waveSeries = ['x', 'y', 'z']
    .filter(k => state.visibleAxes[k])
    .map(k => ({
      label: k.toUpperCase(),
      color: '--' + k,
      points: usable ? samples.map(p => [p.t - last, finite(p[k]) ? p[k] * factor : null]) : [],
    }));

  drawGraph('wave', waveSeries, {
    unit: pref.units,
    xUnit: 's',
    readId: 'waveRead',
    tipId: 'waveTip',
    empty: 'รอสัญญาณความเร่ง',
  });

  const specPts = usable
    ? list(d.spectrum).map(p => [p.hz, finite(p.amplitude) ? p.amplitude * factor : null])
    : [];
  const peakBadge = byId('peakFreq');
  let peak = null;
  for (const pt of specPts) {
    if (finite(pt[0]) && finite(pt[1]) && pt[0] > 0.5 && (!peak || pt[1] > peak[1])) peak = pt;
  }
  if (peak) {
    peakBadge.hidden = false;
    peakBadge.textContent = `Peak ${peak[0].toFixed(1)} Hz · ${formatAxis(peak[1])} ${pref.units}`;
  } else {
    peakBadge.hidden = true;
  }

  drawGraph('spectrum', [{ label: 'FFT', color: '--x', points: specPts }], {
    unit: pref.units,
    xUnit: 'Hz',
    readId: 'specRead',
    tipId: 'specTip',
    empty: 'รอหน้าต่างสัญญาณครบ',
    area: true,
    zeroMin: true,
  });

  drawGraph(
    'trend',
    [{ label: 'RMS', color: '--y', points: recent.map(h => [h.t - end, finite(h.rms) ? h.rms * factor : null]) }],
    {
      unit: pref.units,
      xUnit: 's',
      readId: 'trendRead',
      tipId: 'trendTip',
      empty: 'ยังไม่มีประวัติแรงสั่น',
      area: true,
      zeroMin: true,
    }
  );
}

/* ==========================================================================
   Live Polling from Local Python Backend
   ========================================================================== */
async function refresh() {
  try {
    const res = await fetch('/api/status', { cache: 'no-store', signal: AbortSignal.timeout(3500) });
    if (!res.ok) throw Error();
    const payload = await res.json();
    if (!payload || !Object.hasOwn(stateMeta, payload.state) || typeof payload.connected !== 'boolean') throw Error();
    state.data = payload;
    state.api = true;

    const latest = list(payload.alerts).reduce((v, a) => Math.max(v, a.t || 0), 0);
    if (pref.notices && state.lastAlert !== null && latest > state.lastAlert && state.view !== 'alerts') {
      notify('พบเหตุการณ์ใหม่ ดูรายละเอียดที่ศูนย์แจ้งเตือน', 'amber');
    }
    state.lastAlert = latest;
  } catch {
    state.api = false;
  }
  render();
}

/* ==========================================================================
   Event Listeners
   ========================================================================== */
byId('pause').addEventListener('click', () => {
  state.paused = state.paused ? null : structuredClone(state.data);
  syncPauseButton();
  render();
});

byId('themeButton').addEventListener('click', () => {
  setPref('theme', pref.theme === 'dark' ? 'light' : 'dark');
});

document.querySelectorAll('.axis-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const ax = btn.dataset.axis;
    const activeCount = Object.values(state.visibleAxes).filter(Boolean).length;
    if (state.visibleAxes[ax] && activeCount === 1) return;
    state.visibleAxes[ax] = !state.visibleAxes[ax];
    btn.classList.toggle('active', state.visibleAxes[ax]);
    drawCharts();
  });
});

document.querySelectorAll('[data-range]').forEach(btn => {
  btn.addEventListener('click', () => setPref('range', Number(btn.dataset.range)));
});
for (const k of ['range', 'historyRange']) {
  byId(k).addEventListener('change', e => setPref(k, Number(e.target.value)));
}

document.querySelectorAll('.theme-card').forEach(btn => {
  btn.addEventListener('click', () => setPref('theme', btn.dataset.themeChoice));
});
document.querySelectorAll('[data-unit]').forEach(btn => {
  btn.addEventListener('click', () => setPref('units', btn.dataset.unit));
});
for (const k of ['theme', 'units']) {
  byId(k).addEventListener('change', e => setPref(k, e.target.value));
}

byId('notices').addEventListener('change', e => setPref('notices', e.target.checked));

document.querySelectorAll('[data-alert-filter]').forEach(btn => {
  btn.addEventListener('click', () => {
    state.alertFilter = btn.dataset.alertFilter;
    document.querySelectorAll('[data-alert-filter]').forEach(b => b.classList.toggle('active', b === btn));
    state.alertKey = '';
    renderAlerts();
  });
});
byId('onlyOpen').addEventListener('change', e => {
  state.alertFilter = e.target.checked ? 'open' : 'all';
  state.alertKey = '';
  renderAlerts();
});
byId('ackAllBtn').addEventListener('click', ackAllAlerts);

document.querySelectorAll('[data-hfilter]').forEach(btn => {
  btn.addEventListener('click', () => {
    state.historyFilter = btn.dataset.hfilter;
    document.querySelectorAll('[data-hfilter]').forEach(b => b.classList.toggle('active', b === btn));
    renderHistory();
  });
});

window.addEventListener('resize', drawCharts);
window.addEventListener('hashchange', route);

/* ==========================================================================
   Bootstrap
   ========================================================================== */
setupBars();
syncPrefs();
syncPauseButton();
route();

const updateClock = () => { byId('clock').textContent = timeStr(Date.now() / 1000); };
updateClock();
setInterval(updateClock, 1000);

(async function poll() {
  await refresh();
  setTimeout(poll, 850);
})();
