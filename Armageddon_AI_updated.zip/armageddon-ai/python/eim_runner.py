"""Explicit opt-in to a field-trained GNU/Linux AARCH64 Edge Impulse runner."""
import hashlib
import json
import math
from pathlib import Path
from queue import Empty, Queue
import subprocess
from threading import Thread
import time

from monitor import LABELS


def bounded(proc, job, timeout):
    """Bound both stdin writes and stdout reads; kill the process to release blocked pipes."""
    result = Queue(maxsize=1)

    def perform():
        try:
            result.put((True,job()))
        except Exception as error:
            result.put((False,error))

    worker=Thread(target=perform,daemon=True)
    worker.start()
    try:
        success,value=result.get(timeout=timeout)
    except Empty:
        proc.kill()
        proc.wait(timeout=2)
        worker.join(timeout=1)
        raise TimeoutError("EIM response timed out")
    if not success:
        raise value
    return value


def check_hello(fields):
    if (fields.get("axis_count") != 3 or fields.get("interval_ms") != 16 or
            fields.get("input_features_count") != 768 or
            sorted(fields.get("labels", [])) != sorted(LABELS)):
        raise ValueError("EIM requires 256 XYZ samples at 16 ms and the three field labels")
    if "frequency" in fields and not math.isclose(float(fields["frequency"]),62.5,abs_tol=0.01):
        raise ValueError("Unexpected EIM frequency")
    if fields.get("model_type","classification") != "classification":
        raise ValueError("EIM is not a classifier")


class EimRunner:
    WINDOW, STEP = 256, 128
    independent_performance = False

    def __init__(self, path):
        self.path = Path(path).resolve(strict=True)
        with self.path.open("rb") as model:
            header=model.read(20)
            if (header[:6] != b"\x7fELF\x02\x01" or
                    int.from_bytes(header[18:20],"little") != 183):
                raise ValueError("Expected a 64-bit little-endian AARCH64 ELF export")
            model.seek(0)
            digest=hashlib.sha256()
            for chunk in iter(lambda:model.read(65536),b""):
                digest.update(chunk)
        self.MODEL_VERSION=f"EI {self.path.stem} / {digest.hexdigest()[:12]}"
        self.proc=None
        self.retry_at=0
        self.request_id=0
        self.start()

    def start(self):
        if time.monotonic() < self.retry_at:
            raise RuntimeError("Waiting to restart EIM")
        # Command arguments are separate; the only supported source is an operator-selected file.
        self.proc=subprocess.Popen([str(self.path),"stdin"],stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE,bufsize=0)
        try:
            greeting=bounded(self.proc,lambda:self.proc.stdout.readline(4096),15)
            if b"listening for JSON" not in greeting:
                raise ValueError("Missing EIM stdin handshake")
            check_hello(self.request({"hello":1},timeout=8)["model_parameters"])
        except Exception:
            self.close()
            raise

    def request(self, message, timeout):
        self.request_id+=1
        expected=self.request_id
        payload=(json.dumps(dict(message,id=expected),allow_nan=False)+"\n").encode()
        proc=self.proc

        def exchange():
            # FileIO with bufsize=0 may write a partial message.
            remaining=memoryview(payload)
            while remaining:
                sent=proc.stdin.write(remaining)
                if not sent:
                    raise BrokenPipeError("EIM stdin closed")
                remaining=remaining[sent:]
            raw=proc.stdout.readline(1024*1024)
            if not raw:
                raise EOFError("EIM stdout closed")
            reply=json.loads(raw.strip(b" \r\n\t\x00"))
            if reply.get("id") != expected or reply.get("success") is not True:
                raise ValueError("Invalid EIM protocol response")
            return reply

        return bounded(proc,exchange,timeout)

    def predict(self, rows):
        if len(rows)!=self.WINDOW or any(len(row)!=3 for row in rows):
            raise ValueError("Expected 256 XYZ rows")
        try:
            if self.proc is None:
                self.start()
            scores=self.request({"classify":[float(v) for row in rows for v in row]},
                                timeout=1.2)["result"]["classification"]
            if set(scores)!=set(LABELS):
                raise ValueError("EIM result label set changed")
            return scores
        except Exception:
            if self.proc is not None:
                self.close()
                self.retry_at=time.monotonic()+1
            raise

    def close(self):
        proc,self.proc=self.proc,None
        if proc is not None:
            if proc.poll() is None:
                proc.kill()
            proc.wait(timeout=2)
            proc.stdin.close()
            proc.stdout.close()
