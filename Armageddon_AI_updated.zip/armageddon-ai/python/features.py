"""DC-removed vibration features. Input is XYZ acceleration in g at 62.5 Hz."""
import math
from functools import lru_cache


@lru_cache(maxsize=4)
def fft_plan(n):
    width = n.bit_length() - 1
    order = [int(format(i, f"0{width}b")[::-1], 2) for i in range(n)]
    weights = [0.5 - 0.5 * math.cos(2 * math.pi * i / (n - 1)) for i in range(n)]
    factors = [complex(math.cos(-2 * math.pi * j/n), math.sin(-2 * math.pi * j/n)) for j in range(n//2)]
    return order, weights, factors


def spectrum(values):
    n = len(values)
    order, weights, factors = fft_plan(n)
    result = [complex(values[i] * weights[i]) for i in order]
    width = 2
    while width <= n:
        half = width // 2
        for start in range(0, n, width):
            for k in range(half):
                i = start + k
                v = result[i + half] * factors[k * (n // width)]
                result[i], result[i + half] = result[i] + v, result[i] - v
        width *= 2
    return [abs(v)**2 for v in result[:n//2+1]]


def names(family):
    columns = ["total_rms_g"]
    if family == "rms":
        return columns
    for axis in "xyz":
        columns.extend(f"{axis}_{key}" for key in ("rms_g", "power_share", "crest", "kurtosis", "peak_to_peak_g"))
    for pair in ("xy", "xz", "yz"):
        columns.append("correlation_" + pair)
    if family == "spectrum":
        columns.extend(["band_0_8", "band_8_16", "band_16_24", "band_24_31p25", "peak_hz", "peak_fraction"])
    return columns


def features(rows, family):
    n = len(rows)
    if n < 4 or n & (n-1) or any(len(row) != 3 for row in rows):
        raise ValueError("Expected a power-of-two window of XYZ samples")
    if any(not math.isfinite(value) for row in rows for value in row):
        raise ValueError("Nonfinite acceleration")
    axes = []
    for values in zip(*rows):
        mean = sum(values)/n
        axes.append([v-mean for v in values])
    powers = [sum(v*v for v in axis)/n for axis in axes]
    total = sum(powers)
    out = [math.sqrt(total)]
    if family == "rms":
        return out
    for values, power in zip(axes, powers):
        rms = math.sqrt(power)
        out.extend([rms, power/max(total,1e-30), max(map(abs,values))/max(rms,1e-15),
                    sum(v**4 for v in values)/(n*max(power**2,1e-30)), max(values)-min(values)])
    for i,j in ((0,1),(0,2),(1,2)):
        cross = sum(x*y for x,y in zip(axes[i],axes[j]))/n
        out.append(cross/max(math.sqrt(powers[i]*powers[j]),1e-30))
    if family == "spectrum":
        combined = [sum(bin_values) for bin_values in zip(*(spectrum(a) for a in axes))]
        combined[0] = 0.0
        norm = max(sum(combined),1e-30)
        bands = [0.0]*4
        for index, power in enumerate(combined):
            bands[min(3,int(index*62.5/n//8))] += power/norm
        peak = max(range(1,len(combined)), key=combined.__getitem__)
        out.extend(bands + [peak*62.5/n,combined[peak]/norm])
    return out
