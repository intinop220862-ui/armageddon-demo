"""Three-class portable forest runner. Scores are uncalibrated vote fractions."""
import json
import struct
from pathlib import Path
from features import features

_MODEL = json.loads(Path(__file__).with_name("model.json").read_text(encoding="utf-8"))
WINDOW = _MODEL["window"]
STEP = _MODEL["step"]
MODEL_VERSION = _MODEL["version"]


def predict(window):
    if len(window) != WINDOW:
        raise ValueError(f"Expected {WINDOW} rows")
    values = features(window, _MODEL["family"])
    # sklearn trees evaluate input as float32 while storing float64 thresholds.
    values = struct.unpack(f"{len(values)}f",struct.pack(f"{len(values)}f",*values))
    totals = [0.0]*len(_MODEL["classes"])
    for tree in _MODEL["trees"]:
        node = tree[0]
        while len(node) == 4:
            feature, threshold, left, right = node
            node = tree[left if values[feature] <= threshold else right]
        for k,v in enumerate(node):
            totals[k] += v
    return {name: score/len(_MODEL["trees"]) for name,score in zip(_MODEL["classes"],totals)}
