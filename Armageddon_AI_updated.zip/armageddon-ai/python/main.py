"""App Lab entrypoint and local instrument/replay service."""
import argparse
import atexit
import csv
import logging
import math
import os
from pathlib import Path
from queue import Empty, Full, Queue
import sys
from threading import Thread
import time

from monitor import Monitor, STALE_SECONDS
from webserver import server_for

ROOT = Path(__file__).resolve().parents[1]


def recording(path):
    """Read an original recorder TXT. Metadata is never used by inference."""
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    meta = {}
    for line in lines:
        if line.startswith("# ") and ":" in line:
            key, val = line[2:].split(":", 1)
            meta[key] = val.strip()
    rows = []
    for row in csv.DictReader(l for l in lines if l.strip() and not l.startswith("#")):
        t = int(row["Timestamp_ms"]) * 1000
        xyz = tuple(float(row[f"Acc_{axis}(g)"]) for axis in "XYZ")
        if not 0 <= t < 2**32 or not all(math.isfinite(v) for v in xyz):
            raise ValueError("Invalid recorded sample")
        rows.append((t, *xyz))
    if not rows:
        raise ValueError("Recording contains no samples")
    rpm = int(meta["RPM"]) if meta.get("RPM","").isdigit() else None
    return rows, rpm


def replay(service, rows, loop):
    while True:
        start = time.monotonic()
        elapsed_us = 0
        previous = rows[0][0]
        for tick, x, y, z in rows:
            # File timestamp controls playback, with a short break across resets/gaps.
            delta = (tick - previous) % 2**32
            elapsed_us += min(delta, 2000000)
            previous = tick
            delay = start + elapsed_us / 1e6 - time.monotonic()
            if delay > 0:
                time.sleep(delay)
            service.sample(tick, x, y, z)
        service.disconnect("Recorded file finished")
        if not loop:
            break
        time.sleep(1)


def board_input(service):
    from arduino.app_utils import App, Bridge
    from raw_stream import RawStream

    queue = Queue(maxsize=64)
    stream = RawStream()
    Thread(target=stream.serve,args=(ROOT/".cache"/"nongsea-training.sock",),daemon=True).start()

    def callback(tick, x, y, z):
        stream.publish(tick,x,y,z)
        item = (time.time(), time.monotonic(), tick, x, y, z)
        try:
            queue.put_nowait(item)
        except Full:
            # The subsequent tick gap resets the model; do not block the RPC thread.
            return

    def consume():
        while True:
            try:
                wall, arrival, tick, x, y, z = queue.get(timeout=1)
            except Empty:
                continue
            if time.monotonic() - arrival > STALE_SECONDS:
                service.disconnect("Sampling backlog")
                continue
            try:
                service.sample(tick, x, y, z, wall, arrival)
            except Exception as exc:
                service.disconnect(f"Processing error: {type(exc).__name__}")
                logging.exception("Could not process sample")

    Bridge.provide("armageddon_sample", callback)
    Bridge.provide("armageddon_sensor_status", service.sensor_status)
    Thread(target=consume, daemon=True).start()
    App.run()


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--replay", type=Path)
    mode.add_argument("--board", action="store_true")
    mode.add_argument("--offline", action="store_true")
    parser.add_argument("--port", default=8767, type=int)
    parser.add_argument("--db", type=Path)
    parser.add_argument("--loop", action="store_true", help="Explicitly repeat the recorded file")
    args = parser.parse_args()
    if args.loop and not args.replay:
        parser.error("--loop requires --replay FILE")
    board = args.board or (not args.offline and not args.replay and ROOT == Path("/app"))
    source = "board" if board else "replay" if args.replay else "offline"
    # Use a separate persistent DB for each input mode on disk.
    local_data = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "Armageddon_AI"
    db = args.db or ((ROOT / "data" if board else local_data) / f"{source}.sqlite3")
    selected_eim = os.environ.get("ARMAGEDDON_EIM")
    if board and selected_eim is None:
        selector = ROOT / "data" / "model-selection.txt"
        selection = selector.read_text(encoding="ascii").strip() if selector.exists() else "native"
        if selection not in ("native", "studio"):
            raise ValueError("Unknown saved model selection")
        if selection == "studio":
            selected_eim = str(ROOT / "models" / "field-armageddon.eim")
    if selected_eim:
        from eim_runner import EimRunner
        model = EimRunner(selected_eim)
        atexit.register(model.close)
    else:
        import inference as model
    service = Monitor(db, model, source,
                      args.replay.name if args.replay else "Modulino Movement" if board else "")
    if args.replay:
        rows, service.rpm = recording(args.replay)
    server = server_for(service, "0.0.0.0" if board else "127.0.0.1", args.port)
    print(f"Armageddon AI | {source} | port {args.port} | {model.MODEL_VERSION}", flush=True)
    if board:
        Thread(target=server.serve_forever, daemon=True).start()
        try:
            board_input(service)
        finally:
            server.shutdown()
            server.server_close()
    else:
        if args.replay:
            Thread(target=replay,args=(service,rows,args.loop),daemon=True).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()


if __name__ == "__main__":
    main()
