"""Streaming vibration monitor. Clock timestamps in API responses are epoch seconds."""
import cmath
import csv
import io
import math
import sqlite3
import threading
import time
from collections import deque
from pathlib import Path

LABELS = ("normal", "anomaly", "worst_anomaly")
INTERVAL_US = 16000
STALE_SECONDS = 1.5


def spectrum(rows):
    """One-sided Hann amplitude spectrum, combined vector magnitude in g."""
    n = 1 << (min(len(rows), 256).bit_length() - 1)
    if n < 4:
        return []
    rows = rows[-n:]
    taper = [0.5 - 0.5 * math.cos(2 * math.pi * i / (n - 1)) for i in range(n)]
    power = [0.0] * (n // 2 + 1)
    for axis in zip(*rows):
        mean = sum(axis) / n
        a = [complex((v - mean) * w) for v, w in zip(axis, taper)]
        # In-place radix-two FFT with bit-reversed input order.
        j = 0
        for i in range(1, n):
            bit = n >> 1
            while j & bit:
                j ^= bit
                bit >>= 1
            j ^= bit
            if i < j:
                a[i], a[j] = a[j], a[i]
        size = 2
        while size <= n:
            twiddle = cmath.exp(-2j * math.pi / size)
            half = size // 2
            for start in range(0, n, size):
                phase = 1
                for i in range(start, start + half):
                    v = a[i + half] * phase
                    a[i], a[i + half] = a[i] + v, a[i] - v
                    phase *= twiddle
            size *= 2
        for k in range(len(power)):
            power[k] += abs(a[k]) ** 2
    gain = sum(taper)
    return [dict(hz=k * 62.5 / n,
                 amplitude=math.sqrt(v) * (1 if k in (0, n // 2) else 2) / gain)
            for k, v in enumerate(power)]


class Monitor:
    def __init__(self, path, model, source, detail=""):
        self.model, self.source, self.detail = model, source, detail
        self.lock = threading.RLock()
        self.samples = deque(maxlen=model.WINDOW)
        self.wave = deque(maxlen=375)
        self.ticks = self.last_seen = self.updated = self.last_event = None
        self.heartbeat = None
        self.sensor_code = self.sensor_reads = 0
        self.state, self.reason = "offline", "Waiting for samples"
        self.scores, self.spectral = {}, []
        self.latency = self.rpm = None
        self.count = 0
        self.db_path = Path(path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS history (
              id INTEGER PRIMARY KEY, t REAL, source TEXT, detail TEXT, rpm REAL,
              state TEXT, confidence REAL, rms REAL, latency_ms REAL, duration_s REAL,
              model_version TEXT);
            CREATE INDEX IF NOT EXISTS h_source ON history(source,id);
            CREATE TABLE IF NOT EXISTS alerts (
              id INTEGER PRIMARY KEY,t REAL,source TEXT,detail TEXT,state TEXT,
              confidence REAL,acknowledged INTEGER DEFAULT 0);
            CREATE INDEX IF NOT EXISTS a_source ON alerts(source,id);
        """)

    def _reset(self, reason, offline=False):
        self.samples.clear()
        self.wave.clear()
        self.count = 0
        self.last_event = self.ticks = None
        self.state, self.reason = ("offline" if offline else "unknown"), reason
        self.scores, self.spectral, self.latency = {}, [], None

    def disconnect(self, reason):
        with self.lock:
            self._reset(reason, offline=True)
            self.last_seen = None

    def sensor_status(self, code, reads):
        if code not in (0,1,2,3) or not isinstance(reads,int) or reads < 0:
            return
        with self.lock:
            self.heartbeat = time.monotonic()
            self.sensor_code, self.sensor_reads = code, reads

    def sample(self, tick, x, y, z, captured_at=None, monotonic_at=None):
        """Called serially. A transport gap invalidates the whole partial window."""
        wall = time.time() if captured_at is None else captured_at
        arrival = time.monotonic() if monotonic_at is None else monotonic_at
        with self.lock:
            if self.last_seen is not None and arrival - self.last_seen > STALE_SECONDS:
                self._reset("Stream resumed; collecting a new window")
            self.last_seen, self.updated = arrival, wall
            if not isinstance(tick, int) or not 0 <= tick < 2**32 or not all(
                    isinstance(v,(int,float)) and math.isfinite(v) for v in (x, y, z)):
                self._reset("Invalid sample; collecting a new window")
                return
            if self.ticks is not None and (tick - self.ticks) % 2**32 != INTERVAL_US:
                self._reset("Sample gap; collecting a new window")
            self.ticks = tick
            self.samples.append((x, y, z))
            self.wave.append(dict(t=wall, x=x, y=y, z=z))
            self.count += 1
            if self.state == "offline":
                self.state, self.reason = "unknown", "Collecting samples"
            if len(self.samples) < self.model.WINDOW or (self.count - self.model.WINDOW) % self.model.STEP:
                return
            rows = list(self.samples)
            old = self.state
            self.spectral = spectrum(rows)
            axes = list(zip(*rows))
            energy = 0.0
            for axis in axes:
                mean = sum(axis) / len(axis)
                energy += sum((value - mean)**2 for value in axis) / len(axis)
            rms = math.sqrt(energy)
            self.scores, self.latency = {}, None
            if all(min(axis) == max(axis) for axis in axes):
                self.state, self.reason = "unknown", "Constant sensor window"
            else:
                start = time.perf_counter()
                try:
                    # The board input has one consumer. Let HTTP report a stalled runner
                    # while it works and discard a result if the stream went offline.
                    self.lock.release()
                    try:
                        scores = self.model.predict(rows)
                    finally:
                        self.lock.acquire()
                    if self.last_seen != arrival or time.monotonic()-arrival > STALE_SECONDS:
                        self.disconnect("No recent sample")
                        return
                    if set(scores) != set(LABELS) or any(not math.isfinite(v) or not 0 <= v <= 1 for v in scores.values()) or abs(sum(scores.values())-1) > 0.001:
                        raise ValueError("Invalid model scores")
                    self.state = max(scores, key=scores.get)
                    self.scores = scores
                    self.latency = (time.perf_counter() - start) * 1000
                    self.reason = "Receiving samples"
                except Exception as error:
                    if self.last_seen != arrival or time.monotonic()-arrival > STALE_SECONDS:
                        self.disconnect("No recent sample")
                        return
                    self.state, self.reason = "unknown", f"Inference failed: {type(error).__name__}: {error}"
            confidence = self.scores.get(self.state)
            # Duration describes the observed interval that ended with this decision.
            duration = self.model.STEP * 0.016 if self.last_event is not None else 0
            self.last_event = wall
            with self.db:
                self.db.execute("INSERT INTO history(t,source,detail,rpm,state,confidence,rms,latency_ms,duration_s,model_version) VALUES(?,?,?,?,?,?,?,?,?,?)",
                                (wall, self.source, self.detail, self.rpm, self.state, confidence,
                                 rms, self.latency, duration, self.model.MODEL_VERSION))
                if self.state in LABELS[1:] and self.state != old:
                    self.db.execute("INSERT INTO alerts(t,source,detail,state,confidence) VALUES(?,?,?,?,?)",
                                    (wall, self.source, self.detail, self.state, confidence))

    def snapshot(self):
        with self.lock:
            if self.last_seen is not None and time.monotonic() - self.last_seen > STALE_SECONDS:
                self.disconnect("No recent sample")
            history = [dict(row) for row in self.db.execute(
                "SELECT * FROM history WHERE source=? ORDER BY id DESC LIMIT 600", (self.source,))][::-1]
            alerts = [dict(row) for row in self.db.execute(
                "SELECT * FROM alerts WHERE source=? ORDER BY id DESC LIMIT 200", (self.source,))]
            summary = list(self.db.execute("SELECT state,COUNT(*),SUM(duration_s) FROM history WHERE source=? GROUP BY state", (self.source,)))
            recent_heartbeat = self.heartbeat is not None and time.monotonic()-self.heartbeat < 3
            health = self.reason
            if self.source=="board" and self.state=="offline":
                if recent_heartbeat:
                    health = ("MCU เริ่มทำงาน กำลังตรวจเซนเซอร์",
                              "MCU ตอบกลับ แต่เริ่ม Modulino Movement บน Wire1 ไม่สำเร็จ",
                              "MCU ตอบกลับ แต่อ่านค่าจาก Modulino Movement ไม่สำเร็จ",
                              "MCU รายงานว่าอ่านเซนเซอร์ได้ แต่ Python ยังไม่ได้รับตัวอย่างใหม่")[self.sensor_code]
                else:
                    health = "กำลังรอสัญญาณจาก MCU ผ่าน Bridge"
            return dict(state=self.state, connected=self.last_seen is not None,
                        source=self.source, source_detail=self.detail, model_version=self.model.MODEL_VERSION,
                        rpm=self.rpm, rpm_source="recorded_setpoint" if self.rpm else None,
                        health=health, mcu_heartbeat=recent_heartbeat, mcu_sensor_code=self.sensor_code,
                        mcu_successful_reads=self.sensor_reads, updated_at=self.updated, confidence=self.scores.get(self.state),
                        probabilities=self.scores.copy(), latency_ms=self.latency,
                        waveform=list(self.wave), spectrum=list(self.spectral), history=history,
                        alerts=alerts, window_samples=self.model.WINDOW,
                        history_summary=dict(counts={r[0]:r[1] for r in summary},
                                             duration_s={r[0]:r[2] for r in summary}))

    def ack(self, alert_id):
        with self.lock, self.db:
            return self.db.execute("UPDATE alerts SET acknowledged=1 WHERE id=? AND source=?",
                                   (alert_id,self.source)).rowcount > 0

    def export_csv(self, output):
        # A separate read connection streams the complete history without holding the sampler lock.
        db = sqlite3.connect(self.db_path)
        try:
            cur = db.execute("SELECT * FROM history WHERE source=? ORDER BY id", (self.source,))
            text = io.StringIO(newline="")
            writer = csv.writer(text)
            writer.writerow([c[0] for c in cur.description])
            for row in cur:
                writer.writerow(row)
                if text.tell() > 16384:
                    output.write(text.getvalue().encode())
                    text.seek(0)
                    text.truncate()
            output.write(text.getvalue().encode())
        finally:
            db.close()
