"""Read-only field recorder socket. Empty heartbeats carry no sample values."""
import logging
import math
from pathlib import Path
from queue import Empty, Full, Queue
import socket
import stat


class RawStream:
    def __init__(self):
        self.queue = None

    def publish(self, tick, x, y, z):
        queue = self.queue
        if queue is None:
            return
        if not isinstance(tick,int) or not 0 <= tick < 2**32 or not all(
                isinstance(v,(float,int)) and math.isfinite(v) for v in (x,y,z)):
            return
        try:
            queue.put_nowait(f"{tick // 1000},{x},{y},{z}\n".encode("ascii"))
        except Full:
            # Recorder rejects discontinuous clips. Inference must never wait for a client.
            pass

    def serve(self, path):
        path = Path(path)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                if not stat.S_ISSOCK(path.lstat().st_mode):
                    raise OSError("Existing path is not a Unix socket")
                path.unlink()
            with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as server:
                server.bind(str(path))
                path.chmod(0o600)
                server.listen(1)
                while True:
                    client,_ = server.accept()
                    self.serve_client(client)
        except OSError:
            logging.exception("Raw recording unavailable; inference continues")

    def serve_client(self, client):
        with client:
            client.settimeout(2)
            self.queue = Queue(maxsize=128)
            try:
                while True:
                    try:
                        data=self.queue.get(timeout=1)
                    except Empty:
                        data=b"\n"
                    client.sendall(data)
            except OSError:
                pass
            finally:
                self.queue=None
