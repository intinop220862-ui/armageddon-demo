"""Local monitoring API and allowlisted dashboard assets."""
import json
import mimetypes
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ASSETS = Path(__file__).resolve().parents[1] / "assets"


def server_for(monitor, host, port):
    class Handler(BaseHTTPRequestHandler):
        def send_bytes(self, body, mime="application/json; charset=utf-8", status=200):
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", len(body))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def json(self, value, status=200):
            self.send_bytes(json.dumps(value, allow_nan=False).encode(), status=status)

        def do_GET(self):
            target = urlsplit(self.path).path
            if target == "/api/status":
                self.json(monitor.snapshot())
            elif target == "/api/performance":
                report = Path(__file__).with_name("performance.json")
                self.json(json.loads(report.read_text(encoding="utf-8"))
                          if report.exists() and getattr(monitor.model,"independent_performance",True)
                          else {"available":False,"evidence":"Independent field test pending"})
            elif target == "/api/export.csv":
                self.send_response(200)
                self.send_header("Content-Type","text/csv; charset=utf-8")
                self.send_header("Content-Disposition",'attachment; filename="armageddon-history.csv"')
                self.send_header("Cache-Control","no-store")
                self.end_headers()
                monitor.export_csv(self.wfile)
            else:
                # Assets are public, all other app files (including the database) are private.
                relative = "index.html" if target == "/" else target.lstrip("/")
                f = (ASSETS / relative).resolve()
                if ASSETS not in f.parents or not f.is_file():
                    self.send_error(404)
                    return
                self.send_bytes(f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream")

        def do_POST(self):
            target = re.fullmatch(r"/api/alerts/(\d{1,18})/ack", self.path)
            if not target:
                self.send_error(404)
                return
            origin = self.headers.get("Origin")
            if origin and urlsplit(origin).netloc != self.headers.get("Host"):
                self.send_error(403)
                return
            found = monitor.ack(int(target.group(1)))
            self.json({"ok":found}, 200 if found else 404)

        def log_message(self, fmt, *args):
            if args and str(args[0]).startswith("GET /api/status"):
                return
            super().log_message(fmt, *args)

    return ThreadingHTTPServer((host, port), Handler)
