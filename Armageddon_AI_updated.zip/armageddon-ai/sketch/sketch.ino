#include <Modulino.h>
#include <Arduino_RouterBridge.h>

ModulinoMovement movement;
constexpr uint32_t periodUs = 16000;
uint32_t nextTick;
bool ready;
unsigned int failedReads;
uint32_t nextStatusMs;
uint32_t successfulReads;
// 0 = starting, 1 = begin failed, 2 = read failed, 3 = reading.
int sensorState;

void setup() {
  Bridge.begin();
  Monitor.begin(115200);
  Modulino.begin(Wire1);
  nextTick = micros();
}

void loop() {
  const uint32_t nowMs = millis();
  if (static_cast<int32_t>(nowMs - nextStatusMs) >= 0) {
    Bridge.notify("armageddon_sensor_status", sensorState, successfulReads);
    nextStatusMs = nowMs + 1000;
  }
  const uint32_t now = micros();
  if (static_cast<int32_t>(now - nextTick) < 0) return;
  if (!ready) {
    ready = movement.begin();
    if (!ready) {
      sensorState = 1;
      Monitor.println("Waiting for Modulino Movement");
      nextTick = now + 1000000;
      return;
    }
    nextTick = micros();
    failedReads = 0;
  }
  const uint32_t tick = nextTick;
  nextTick += periodUs;
  if (static_cast<int32_t>(now - nextTick) >= 0) nextTick = now + periodUs;
  if (!movement.update()) {
    sensorState = 2;
    if (++failedReads >= 8) ready = false;
    return;
  }
  failedReads = 0;
  sensorState = 3;
  ++successfulReads;
  Bridge.notify("armageddon_sample", tick, movement.getX(), movement.getY(), movement.getZ());
}
